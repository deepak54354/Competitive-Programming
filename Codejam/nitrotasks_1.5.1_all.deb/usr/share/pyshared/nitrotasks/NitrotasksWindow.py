# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2012 Caffeinated Code <http://caffeinatedco.de>
# Copyright (C) 2012 Jono Cooper
# Copyright (C) 2012 George Czabania
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
# 
# Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
# Neither the name of Caffeinated Code nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
### END LICENSE

import gettext
from gettext import gettext as _
gettext.textdomain('nitrotasks')

import webbrowser, os, sys, re, pickle, urllib, urllib2, threading
from gi.repository import Gtk, WebKit, Unity, GObject # pylint: disable=E0611
import logging
logger = logging.getLogger('nitrotasks')

from nitrotasks_lib import Window
from nitrotasks_lib.helpers import get_media_file

GObject.threads_init()

# See nitrotasks_lib.Window.py for more details about how this class works
class NitrotasksWindow(Window):
    __gtype_name__ = "NitrotasksWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(NitrotasksWindow, self).finish_initializing(builder)

        "LOCALSTORAGE POLYFILL"
        home = os.getenv('HOME')
        # Try load data
        try:
            storage_file = open(home + '/.nitrodata.pkl', 'r')
            localstorage = pickle.load(storage_file)
            storage_file.close()
        except:
            # Don't make a file
            localstorage = {'tasks': '(null)', 'lists': '(null)', 'prefs': '(null)'}


        # Toolbar
        self.scrolledwindow = self.builder.get_object("scrolledwindow")
        self.toolbar = self.builder.get_object("toolbar1")
        self.add_button = self.builder.get_object("add_button")
        self.delete_button = self.builder.get_object("delete_button")
        self.sort_button = self.builder.get_object("sort_button")
        self.sync_button = self.builder.get_object("sync_button")
        self.settings_button = self.builder.get_object("settings_button")
        self.search_entry = self.builder.get_object("search_entry")

        self.magic = self.builder.get_object("magic")
        self.priority = self.builder.get_object("priority")
        self.date = self.builder.get_object("date")
        self.manual = self.builder.get_object("manual")

        # Menubar
        self.newtask = self.builder.get_object("newtask")
        self.newlist = self.builder.get_object("newlist")
        self.sync = self.builder.get_object("sync")
        self.today = self.builder.get_object("today")
        self.next = self.builder.get_object("next")
        self.logbook = self.builder.get_object("logbook")
        self.alltasks = self.builder.get_object("alltasks")
        self.prefs = self.builder.get_object("prefs")
        self.mnu_contents = self.builder.get_object("mnu_contents")
        self.mnu_donate = self.builder.get_object("mnu_donate")
        self.mnu_donors = self.builder.get_object("mnu_donors")
        self.mnu_about = self.builder.get_object("mnu_about")

        self.webview = WebKit.WebView()
        self.scrolledwindow.add(self.webview)
        self.webview.props.settings.enable_default_context_menu = False
        self.webview.load_uri(get_media_file('app/index.html'))
        self.webview.show()

        # Cross Domain AJAX
        s = self.webview.get_settings()
        s.set_property("enable-universal-access-from-file-uris", True)

        launcher = Unity.LauncherEntry.get_for_desktop_id ("nitrotasks.desktop")

        def external(this, widget, data = None):
            self.webview.execute_script('cmd("' + this.get_action_name() + '")')

        def menuexternal(this, widget, data = None):
            self.webview.execute_script('cmd("' + this.get_name() + '")')

        def search(this, widget, data = None):
            self.webview.execute_script('$search.val("' + this.get_text() + '").keyup()')

        def sort(this, widget, data = None):
            if self.magic.get_active() == True:
                self.webview.execute_script('cmd("sort-magic")')
                print "magic"
            elif self.priority.get_active() == True:
                self.webview.execute_script("cmd('sort-priority')")
                print "priority"
            elif self.date.get_active() == True:
                self.webview.execute_script('cmd("sort-date")')
                print "date"
            elif self.manual.get_active() == True:
                self.webview.execute_script("console.log('derp')")
                self.webview.execute_script("cmd('sort-default')")
                print "default"

        class MyHandler(urllib2.HTTPHandler):
            def http_response(this, req, response):
                print response
                for l in response:
                    data = l

                data = data.replace("'", "\\'")

                print data
                GObject.idle_add(self.webview.execute_script,"sync.ajaxdata.data = JSON.parse('" + data + "')")
                return response

        def _navigation_requested_cb(view, frame, networkRequest):
            uri = networkRequest.get_uri()
            if uri[:7] != 'file://':
                webbrowser.open(uri)

            return 1

        def title_changed(widget, frame, title):
            if title != 'null':

                title = title.split("|")

                #Gets Data from Disk
                if title[0] == 'get':
                    scriptbody = localstorage[title[1]]
                    script = "xcode = '" + scriptbody + "'"
                    self.webview.execute_script(script)

                elif title[0] == 'theme':
                    if title[1] == 'linux':
                        self.toolbar.show()
                        #Change UI Color
                        style_context = self.get_style_context()
                        jono = style_context.lookup_color('selected_bg_color')
                        self.webview.execute_script('colorize("' + jono[1].to_string() + '")')

                    else:
                        self.toolbar.hide()

                elif title[0] == 'count':
                    launcher.set_property("count", int(title[1]))
                    launcher.set_property("count_visible", True)

                elif title[0] == 'deleteOld':
                    os.remove(home + '/.nitrodata.pkl')

                elif title[0] == 'isolate_window':
                    print "Opening window... If this doesn't work, somethings wrong."
                    isolatewindow = Gtk.Window()
                    isolatewebview = WebKit.WebView()
                    isolatescroller = Gtk.ScrolledWindow()
                    isolatewebview.load_uri(title[1])

                    isolatescroller.add(isolatewebview)
                    isolatewindow.add(isolatescroller)
                    isolatewindow.set_title("Authorize Nitro")
                    isolatewindow.set_size_request(960, 450)
                    isolatewindow.show_all()                


        self.webview.connect('title-changed', title_changed)
        self.webview.connect('navigation-requested', _navigation_requested_cb)

        # Code for other initialization actions should be added here.
        self.add_button.connect ("clicked", external, None)
        self.delete_button.connect ("clicked", external, None)
        self.sort_button.connect ("clicked", sort, None)
        self.sync_button.connect ("clicked", external, None)
        self.settings_button.connect ("clicked", external, None)

        self.search_entry.connect ("key-release-event", search, None)

        self.newtask.connect ("activate", menuexternal, None)
        self.newlist.connect ("activate", menuexternal, None)
        self.sync.connect ("activate", menuexternal, None)
        self.today.connect ("activate", menuexternal, None)
        self.next.connect ("activate", menuexternal, None)
        self.logbook.connect ("activate", menuexternal, None)
        self.alltasks.connect ("activate", menuexternal, None)
        self.prefs.connect ("activate", menuexternal, None)
        self.mnu_contents.connect ("activate", menuexternal, None)
        self.mnu_donate.connect ("activate", menuexternal, None)
        self.mnu_donors.connect ("activate", menuexternal, None)
        self.mnu_about.connect ("activate", menuexternal, None)